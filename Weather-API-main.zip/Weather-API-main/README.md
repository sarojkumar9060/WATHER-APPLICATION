# Weather-API
Simple weather app using HTML, CSS, and JavaScript

## Deploy Link
https://mellow-buttercream-1fc890.netlify.app/


